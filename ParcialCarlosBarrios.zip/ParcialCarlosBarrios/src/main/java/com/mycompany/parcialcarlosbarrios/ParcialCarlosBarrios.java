/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.parcialcarlosbarrios;

/**
 *
 * @author Santi
 */
public class ParcialCarlosBarrios {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
