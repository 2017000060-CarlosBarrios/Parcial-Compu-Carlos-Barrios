/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Mene;

import javax.swing.JOptionPane;

/**
 *
 * @author Santi
 */
public class jfrm {
    public static void main(String[] args) {
        String clave;
        clave = JOptionPane.showInputDialog("Ingrese la contraseña:");
        if (clave.equals("12345")) { 
            JOptionPane.showMessageDialog(null,"Bienvenido");
        Parcial.jfrm v = new Parcial.jfrm();
        v.setVisible(true);
        
    } else {
           JOptionPane.showMessageDialog(null,"Contraseña incorrecta");

        }
    }
}

